# Samsung Galaxy A15 4G — privacy ROM project

A device-specific, LineageOS-based ROM project for **Samsung SM-A155F / A155F**, with privacy-first defaults and optional sandboxed Google Play compatibility.

**Status: research/planning and documentation only. There is no flashable release, validated device tree, or tested Play compatibility port in this repository.** This is not the SM-A156x / A15 5G project and is not affiliated with LineageOS, GrapheneOS, Samsung, or Google.

## Goals

- Stable device-specific hardware integration rather than relying on an unadapted GSI.
- A usable Play-free default with optional official Play services/Store as regular sandboxed apps through a maintained compatibility layer.
- User choice without misrepresenting privileged GApps, microG, and sandboxed Play as the same design.
- Reproducible development, honest security claims, and durable handoffs between development chats.

GrapheneOS-inspired features do not imply GrapheneOS-equivalent security or official support. Device firmware, kernel, hardware features, verified boot, and update coverage must be assessed independently.

## Start here

| File | Purpose |
| --- | --- |
| [PROJECT_STATE.md](PROJECT_STATE.md) | Live status, evidence, blockers, and the next action |
| [MASTER_PROMPT.md](MASTER_PROMPT.md) | Copy/paste handoff for a new development chat |
| [AGENTS.md](AGENTS.md) | Contributor/agent workflow and persistence rules |
| [CHANGELOG.md](CHANGELOG.md) | Human-readable history of meaningful changes |
| [docs/ROADMAP.md](docs/ROADMAP.md) | Phases and acceptance gates |
| [docs/DECISIONS.md](docs/DECISIONS.md) | Accepted, proposed, and deferred decisions |
| [docs/RESEARCH.md](docs/RESEARCH.md) | Public references, findings, and uncertainty |
| [docs/DEVICE_INVENTORY.md](docs/DEVICE_INVENTORY.md) | Read-only data collection and missing device/host facts |

## Initial baseline

User-reported device/firmware: **SM-A155F**, `A155FXXS7CYG3`, Android 15 stable. This has not yet been independently checked with device output. The current runtime, bootloader/root/recovery state, GSI version, and build-host specifications are still unknown.

## Repository and publishing status

At initialization, no destination URL, remote branch, or authenticated GitHub write access had been supplied. The initial environment's GitHub connector lookup returned unsupported. These files are a portable bootstrap; their existence does not establish that they have been pushed anywhere.

For an existing repository, review and merge the files intentionally. **Do not blindly replace an existing README, AGENTS file, ignore rules, license, or history.** The recommended first contribution is a review branch/PR, unless the owner approves another workflow. Never embed an API token in a repository URL or file.

Before a new chat, push the checkpoint and supply the repository URL plus branch/commit alongside `MASTER_PROMPT.md`. For a private repository, authorize access through a secure mechanism or provide a sanitized checkout/archive; a URL alone is insufficient.

## Source and distribution policy

No ROM sources, third-party code, firmware images, proprietary blobs, signing keys, or device dumps are included in this bootstrap. A project-wide license is not yet selected. Preserve upstream licenses and attribution when code is introduced; do not assume this repository can relicense imported material.

There are deliberately no flashing instructions or release claims at this stage.
